SELECT TOP (1000) [Username]
      ,[E_mail]
      ,[contact]
      ,[Password]
  FROM [master].[dbo].[Customer]
  select*from Customer;
    select*from admin;